#Librerias
library(readxl)
library(data.table)
library(sqldf)
library(stringr)
library(fuzzyjoin)
library(dplyr)

###################### Fuentes de datos #################################################
# #access LMS
# LMS_Data <- read.table("C:/Users/rfpardo/OneDrive - Inter-American Development Bank Group/CRM/LMS_Data/LMS_AccountsAccessExport.txt", header = TRUE, sep = ",", dec = ".")
# # LMS Filtro para chile
# CLP <- LMS_Data[which(LMS_Data$CNTRY_NM == "CHILE"),]
# # tengo 361 registros de chile

# Cuentas Activas de CL LMS al 20190605
CLP_Active<-read_xlsx("C:/Users/rfpardo/OneDrive - Inter-American Development Bank Group/CRM/LMS_Data/Active Institutions in LMS_CH June 5 2019.xlsx", col_names = TRUE, sheet = "Clean List")
CLP_Active <- as.data.frame(apply(CLP_Active,2,stringr::str_squish))
# Outlook de Representacion
CLP_RepContact<-read.csv(file = "C:/Users/rfpardo/Documents/RP_CLP201906/CONTACTOS REP CCH.csv", sep = ",", quote="\"", header=TRUE, encoding = "UTF-8", na.strings=c("NA","NaN", " "))
CLP_RepContact <- as.data.frame(apply(CLP_RepContact,2,stringr::str_squish))
## creo df de duplicados: dup
# convierto rowname en columna para no perder el ordenamiento cuando haga el sort
setDT(CLP_Active, keep.rownames = TRUE)[]

CLP_Active$NameMod <- tolower(CLP_Active$`Clean List Proper full name - Institution`)

CLP_Active <- CLP_Active[order(CLP_Active$NameMod),]
dup<-NULL
for(i in 2:nrow(CLP_Active))
{
  dup[[i-1]]<- agrep( CLP_Active$NameMod[[i-1]], CLP_Active$NameMod[[i]], max.distance = 0.1, costs = NULL,
                      ignore.case = FALSE, value = TRUE, fixed = TRUE,
                      useBytes = FALSE)
}

dup<-data.frame(dup = unlist(dup))  

# Marco en la tabla de cuentas activas las cuentas duplicadas 

CLP_Active<-sqldf('SELECT CLP_Active.*, dup.dup as DuplicadoLMS FROM CLP_Active LEFT JOIN dup on CLP_Active.NameMod=dup.dup')

# borro los duplicados que no voy a tomar en cuenta
target <- c(29,36,47)
CLP_Active <- CLP_Active %>% filter(!rn %in% target)
# row 29 ch_mec
# row 36 ch_mt
# row 47 ch_ssc


# Salesforce Chile ##

load("C:/Users/rfpardo/OneDrive - Inter-American Development Bank Group/CRM/RData/RP_Account_18-Jun-2019 14.48.Rda")

SF_CLP <- sqldf('SELECT Account.* FROM Account where BillingCountry == "Chile"') # BillingCountry es el que usan ahora luego del country__c

## ya tengo 133 cuentas de chile en salesforce
# como es un kilombo la cantidad de columnas voy a limpiar un poco

SF_CLP<-sqldf('SELECT SF_CLP.Id, SF_CLP.ACRNM__c,
                             SF_CLP.Abbreviation__c,
                             SF_CLP.Name,
                             SF_CLP.OwnerId,
                             SF_CLP.BillingStreet,
                             SF_CLP.BillingCity,
                             SF_CLP.BillingPostalCode,
                             SF_CLP.Phone,
                             SF_CLP.PersonMobilePhone,
                             SF_CLP.Website,
                             SF_CLP.Description,
                             SF_CLP.Institution_Type__c,
                             SF_CLP.Institution_Sub_type__c,
                             SF_CLP.Public_Private_Sector__c,                     
                             SF_CLP.Relationship_with_the_bank__c,
                             SF_CLP.ParentId,
                             SF_CLP.email__c  FROM SF_CLP')

# cuales de las cuentas de SF tienen contqactos asociados
Contact <-read.table(file = "C:/Users/rfpardo/Downloads/Contact20190618.csv", sep = ",", quote="\"", header=TRUE, encoding = "UTF-8", na.strings=c("NA","NaN", " "))
# unique(rbind(a,b), by = "lastupdate", fromLast = TRUE)

ContactByAccount <- sqldf('SELECT AccountId, count(Id) as CantidadContactos FROM Contact group by AccountId')

SF_CLP<-sqldf('SELECT SF_CLP.*,ContactByAccount.CantidadContactos FROM SF_CLP LEFT JOIN ContactByAccount on SF_CLP.Id= ContactByAccount.AccountId')

# borro los duplicados que no voy a tomar en cuenta
target <- c("CH-UCC")
SF_CLP <- SF_CLP %>% filter(!ACRNM__c %in% target)

# row 45 CH_UCC

colnames(CLP_Active)[colnames(CLP_Active)=="acronym"] <- "ACRNM__c"
colnames(CLP_Active)[colnames(CLP_Active)=="Clean List Proper full name - Institution"] <- "Name"
colnames(CLP_Active)[colnames(CLP_Active)=="Clean List  Proper full name - Parent Institution"] <- "ParentName"
colnames(CLP_Active)[colnames(CLP_Active)=="records"] <- "CantidadOperaciones"

#cuales de la lista activa de lms estan en salesforce
# marco en el ds de SF las que estan activas para hacer el append con las que no porque las activas que estan en ambos conjuntos las tomo del ds de CLP_Active

ij<- merge(CLP_Active,SF_CLP, by="ACRNM__c")
ij$ActivasYenSF <- 1
ij$Activas <- 1
ij$enSF <- 1
SF_CLP<-sqldf('SELECT SF_CLP.*, ij.Activas, ij.enSF FROM SF_CLP LEFT JOIN ij on SF_CLP.ACRNM__c= ij.ACRNM__c')
SF_CLP$Activas[is.na(SF_CLP$Activas)] <- 0
SF_CLP$enSF[is.na(SF_CLP$enSF)] <- 1

SF_CLP1<- SF_CLP[which(!(SF_CLP$CantidadContactos==0)&(SF_CLP$Activas==0)&(SF_CLP$enSF==1)),]
#SF_CLP1 son las no activas en SF con contacos
# corrijo numero de telefono

SF_CLP1$Phone <- gsub("[^0-9]", "",SF_CLP1$Phone)
SF_CLP1$Phone <- ifelse(!is.na(SF_CLP1$Phone),paste("+", SF_CLP1$Phone, sep=""), NA)

CLP_ActiveR <- sqldf('SELECT CLP_Active.*,
                             SF_CLP.Id,
                             SF_CLP.Abbreviation__c,
                             SF_CLP.OwnerId,
                             SF_CLP.BillingStreet,
                             SF_CLP.BillingCity,
                             SF_CLP.BillingPostalCode,
                             SF_CLP.Phone,
                             SF_CLP.Website,
                             SF_CLP.Description,
                             SF_CLP.Institution_Type__c,
                             SF_CLP.Institution_Sub_type__c,
                             SF_CLP.Public_Private_Sector__c,                     
                             SF_CLP.Relationship_with_the_bank__c,
                             SF_CLP.ParentId,
                             SF_CLP.email__c, SF_CLP.CantidadContactos, SF_CLP.Activas, SF_CLP.enSF  FROM CLP_Active LEFT JOIN SF_CLP
                             on SF_CLP.ACRNM__c =CLP_Active.ACRNM__c')
#En CLP_ActiveR son todas activas
CLP_ActiveR$Activas <-1
#pero algunas no estan en SF
CLP_ActiveR$enSF[is.na(CLP_ActiveR$enSF)] <- 0
# y de las que no estan en SF no se cuanto contactos tienen por eso el join vacio lo reemplazo con 0
CLP_ActiveR$CantidadContactos[is.na(CLP_ActiveR$CantidadContactos)] <- 0

# voy a limpiar y enriquecer los numeros de telefonos para las activas que estan en SF

# corrijo numero de telefono
CLP_ActiveR$tel_num <- gsub("[^0-9]", "",CLP_ActiveR$tel_num)
CLP_ActiveR$Phone <- gsub("[^0-9]", "",CLP_ActiveR$Phone)

CLP_ActiveR$Phone1 <- NA
CLP_ActiveR$Phone2 <- NA
# si tengo numero de telefono en ambos en el secundario pongo lo que viene de lms
CLP_ActiveR$Phone2<-ifelse(!is.na(CLP_ActiveR$Phone)&!is.na(CLP_ActiveR$tel_num), CLP_ActiveR$tel_num,NA)
# si el de sf no esta vacio pongo en el primario lo que vino de sf y si esta vacio lo que vino de lms
CLP_ActiveR$Phone1<-ifelse(!is.na(CLP_ActiveR$Phone), CLP_ActiveR$Phone,CLP_ActiveR$tel_num)
# si el primario y el secundario coinciden dejo en blaco el secundario
CLP_ActiveR$Phone2<-ifelse(CLP_ActiveR$Phone2==CLP_ActiveR$Phone1,NA ,CLP_ActiveR$Phone2)
# les agrego el +
CLP_ActiveR$Phone1 <- ifelse(!is.na(CLP_ActiveR$Phone1),paste("+", CLP_ActiveR$Phone1, sep=""), NA)
CLP_ActiveR$Phone2 <- ifelse(!is.na(CLP_ActiveR$Phone2),paste("+", CLP_ActiveR$Phone2, sep=""), NA)
CLP_ActiveR$Phone <- NULL
CLP_ActiveR$tel_num <- NULL
colnames(CLP_ActiveR)[colnames(CLP_ActiveR)=="Phone1"] <- "Phone"
colnames(CLP_ActiveR)[colnames(CLP_ActiveR)=="Phone2"] <- "PersonMobilePhone"
CLP_ActiveR$Phone1 <- NULL
CLP_ActiveR$Phone2 <- NULL

# me quedo con las cuentas de los paises con codigo CH
CLP_ActiveR <- CLP_ActiveR[which(CLP_ActiveR$'Clean List  Country IDB Code' == "CH"),]

# ahora tengo que hacer el append con las que no estaban activas pero tenian contactos SF_CLP1 (tienen que tener las mismas columnnas para rbind pero no importa el orden)
setdiff(colnames(CLP_ActiveR), colnames(SF_CLP1))
SF_CLP1$DuplicadoLMS <- NA
#puede ser que tengan pero hay que hacer el join yo lleno para poder mergear
SF_CLP1$CantidadOperaciones <-0
SF_CLP1$NameMod <- tolower(SF_CLP1$Name)
setdiff(colnames(CLP_ActiveR), colnames(SF_CLP1))
CLP_ActiveRR<- CLP_ActiveR[ ,!(colnames(CLP_ActiveR) %in% setdiff(colnames(CLP_ActiveR), colnames(SF_CLP1)))]
setdiff(colnames(CLP_ActiveRR), colnames(SF_CLP1))
setdiff(colnames(SF_CLP1), colnames(CLP_ActiveRR))
#apendeo las activas 45 con las no activas con contactos 62.
CLP_ActiveRR[] <- lapply(CLP_ActiveRR, as.character)
SF_CLP1[] <- lapply(SF_CLP1, as.character)

CLP_Account <- rbind(CLP_ActiveRR, SF_CLP1)

CLP_Account$BillingCountry <- "Chile"
CLP_Account$BillingCountryCode <- "CL"

# CLP Account es la lista de cuentas de LMS activas con los campos de salesforce para las que ya existian en salesforce mas las no activas que tienen contactos en SF.
CLP_Account$BillingCity<-ifelse(grepl("Santiago",CLP_Account$BillingCity),"Santiago de Chile",CLP_Account$BillingCity)

CLP_Account$BillingStreet<-stringr::str_to_title(CLP_Account$BillingStreet)
CLP_Account$BillingCity<-stringr::str_to_title(CLP_Account$BillingCity)
CLP_Account$Name<-stringr::str_to_title(CLP_Account$Name)



Path = "/Users/rfpardo/documents/Rdata/"
AccountPath = paste0(Path,"RP_CLP_Account_",format(Sys.time(), "%d-%b-%Y %H.%M"), ".Rda")
save(CLP_Account,file=AccountPath)

## Trabajo datos de contactos

# NA Variables
navars <- data.frame(colSums(is.na(CLP_RepContact))<nrow(CLP_RepContact))
navars<-setDT(navars, keep.rownames = TRUE)[]
colnames(navars)<- c("Field", "NotNAField")
table(navars$NotNAField)
# FALSE  TRUE 
# 61    31
CLP_RepContact <- CLP_RepContact[,colSums(is.na(CLP_RepContact))<nrow(CLP_RepContact)]   
nonunary <- function(x) length(unique(x))>1
CLP_RepContact<- CLP_RepContact[sapply(CLP_RepContact,nonunary)]
CLP_RepContact<- CLP_RepContact[,-c(18,19,21,22,23,24)]
colnames(CLP_RepContact)
# ## Exporto para Romina N limpieza de mails
# EmailRepresentante <- CLP_RepContact[,c(1,2,3,17,18)]
# Path = "C:/Users/rfpardo/Documents/RP_CLP201906/"
# TablePath = paste0(Path,"RP_CLP_EmailsRepContact_",format(Sys.time(), "%d-%b-%Y %H.%M"), ".csv")
# write.table(EmailRepresentante, TablePath,row.names=FALSE, na="", sep=",")

# saco los mails VIP, todos los contactos sean BID, los contactos sin mails y los que tienen mail invalidos.

CLP_RepContact <- CLP_RepContact[which(CLP_RepContact$Private == FALSE),]
CLP_RepContact <- CLP_RepContact[which(!(CLP_RepContact$Company %in% c("BID", "BID Invest", "Banco Interamericano de Desarrollo", "Banco Interamericano de Desarrollo Invest"))),]
CLP_RepContact <- CLP_RepContact[which(!is.nan(CLP_RepContact$E.mail.Address)),]
CLP_RepContact <- CLP_RepContact[which(CLP_RepContact$E.mail.Address != ""),]
CLP_InvalidEmail<-read.table(file = "C:/Users/rfpardo/Documents/RP_CLP201906/emails chile_invalid.csv", sep = ",", quote="\"", header=TRUE, encoding = "UTF-8", na.strings=c("NA","NaN", " "))

CLP_RepContact<-sqldf('SELECT * from CLP_RepContact WHERE [E.mail.Address] NOT IN(SELECT email FROM CLP_InvalidEmail)')

colnames(CLP_RepContact) <- c("FirstName",
                              "MiddleName",
                              "LastName",
                              "Company",
                              "Department",
                              "Position_Stakeholder__c",
                              "MailingStreet",
                              "MailingCity",
                              "MailingState",
                              "MailingCountry",
                              "AssistantPhone",
                              "Phone",
                              "OtherPhone",
                              "OtherPhone1",
                              "MobilePhone",
                              "AssistantName",
                              "Email",
                              "Additional_e_mail__c",
                              "VIP__c",
                              "Website")



# Mapeo Oficial_Job_Title__c (Position)

CLP_RepContact$Oficial_Job_Title__c<-NA
CLP_RepContact$Oficial_Job_Title__c<- ifelse(grepl('Secretaria',CLP_RepContact$Position_Stakeholder__c),'Secretary - Secretary',CLP_RepContact$Oficial_Job_Title__c)
CLP_RepContact$Oficial_Job_Title__c<- ifelse(grepl('Secretario',CLP_RepContact$Position_Stakeholder__c),'Secretary - Secretary',CLP_RepContact$Oficial_Job_Title__c)
CLP_RepContact$Oficial_Job_Title__c<- ifelse(grepl('Director',CLP_RepContact$Position_Stakeholder__c),'Director - Director',CLP_RepContact$Oficial_Job_Title__c)
CLP_RepContact$Oficial_Job_Title__c<- ifelse(grepl('Presidente',CLP_RepContact$Position_Stakeholder__c),'CEO-President/Minister - CEO-President/Minister',CLP_RepContact$Oficial_Job_Title__c)
CLP_RepContact$Oficial_Job_Title__c<- ifelse(grepl('CEO',CLP_RepContact$Position_Stakeholder__c),'CEO-President/Minister - CEO-President/Minister',CLP_RepContact$Oficial_Job_Title__c)
CLP_RepContact$Oficial_Job_Title__c<- ifelse(grepl('Manager',CLP_RepContact$Position_Stakeholder__c),'Manager - Manager',CLP_RepContact$Oficial_Job_Title__c)
CLP_RepContact$Oficial_Job_Title__c<- ifelse(grepl('Gerente',CLP_RepContact$Position_Stakeholder__c),'Manager - Manager',CLP_RepContact$Oficial_Job_Title__c)
CLP_RepContact$Oficial_Job_Title__c<- ifelse(grepl('Alcalde',CLP_RepContact$Position_Stakeholder__c),'Mayor - Mayor',CLP_RepContact$Oficial_Job_Title__c)
CLP_RepContact$Oficial_Job_Title__c<- ifelse(grepl('Coordinador',CLP_RepContact$Position_Stakeholder__c),'Project/Program Coordinator - Project/Program Coordinator',CLP_RepContact$Oficial_Job_Title__c)
CLP_RepContact$Oficial_Job_Title__c<- ifelse(grepl('Asistente',CLP_RepContact$Position_Stakeholder__c),'',CLP_RepContact$Oficial_Job_Title__c)



# limpieza numero de telefnos

CLP_RepContact$OtherPhone <- paste(CLP_RepContact$OtherPhone, "", CLP_RepContact$OtherPhone1)
CLP_RepContact$OtherPhone1<- NULL



CLP_RepContact$AssistantPhone <- gsub("[^0-9]", "",CLP_RepContact$AssistantPhone)
CLP_RepContact$Phone <- gsub("[^0-9]", "",CLP_RepContact$Phone)
CLP_RepContact$OtherPhone <- gsub("[^0-9]", "",CLP_RepContact$OtherPhone)
CLP_RepContact$MobilePhone <- gsub("[^0-9]", "",CLP_RepContact$MobilePhone)

CLP_RepContact[CLP_RepContact==""] <- NA
CLP_RepContact$AssistantPhone<-ifelse(!is.na(CLP_RepContact$AssistantPhone),paste("+",CLP_RepContact$AssistantPhone, sep=""),NA)
CLP_RepContact$Phone<-ifelse(!is.na(CLP_RepContact$Phone),paste("+",CLP_RepContact$Phone, sep=""),NA)
CLP_RepContact$OtherPhone<-ifelse(!is.na(CLP_RepContact$OtherPhone),paste("+",CLP_RepContact$OtherPhone, sep=""),NA)
CLP_RepContact$MobilePhone<-ifelse(!is.na(CLP_RepContact$MobilePhone),paste("+",CLP_RepContact$MobilePhone, sep=""),NA)
colnames(CLP_RepContact)

CLP_RepContact1 <- CLP_RepContact
CLP_RepContact<- CLP_RepContact[,c("FirstName","MiddleName","LastName","Company","Department", "Oficial_Job_Title__c","Position_Stakeholder__c",
                   "MailingStreet","MailingCity","MailingState","MailingCountry",         
                   "AssistantPhone","Phone","OtherPhone","MobilePhone","AssistantName","Email","Additional_e_mail__c")]
CLP_RepContact$FirstName<- str_to_title(CLP_RepContact[,c("FirstName")])
CLP_RepContact$MiddleName<- str_to_title(CLP_RepContact[,c("MiddleName")])
CLP_RepContact$LastName<- str_to_title(CLP_RepContact[,c("LastName")])
CLP_RepContact$Company<- str_to_title(CLP_RepContact[,c("Company")])
CLP_RepContact$Department<- str_to_title(CLP_RepContact[,c("Department")])
CLP_RepContact$MailingStreet<- str_to_title(CLP_RepContact[,c("MailingStreet")])
CLP_RepContact$MailingCity<- str_to_title(CLP_RepContact[,c("MailingCity")])
CLP_RepContact$MailingState<- str_to_title(CLP_RepContact[,c("MailingState")])
CLP_RepContact$MailingCountry<- str_to_title(CLP_RepContact[,c("MailingCountry")])
CLP_RepContact$Position_Stakeholder__c<- str_to_title(CLP_RepContact[,c("Position_Stakeholder__c")])
CLP_RepContact$Oficial_Job_Title__c<- str_to_title(CLP_RepContact[,c("Oficial_Job_Title__c")])
# pongo todo en NA porque estan mal
CLP_RepContact$MailingCity<- NA
CLP_RepContact$MailingState<- NA
CLP_RepContact$MailingCountry<- NA

unique(substr(CLP_RepContact$Phone, 2, 3))

# voy a tomar el pais del telefono
CLP_RepContact$MailingCountry<-substr(CLP_RepContact$Phone, 2, 3)
CLP_RepContact$MailingCountry<-gsub("56", "Chile",CLP_RepContact$MailingCountry)
CLP_RepContact$MailingCountry<-gsub("30", "Grecia",CLP_RepContact$MailingCountry)
CLP_RepContact$MailingCountry<-gsub("52", "Mexico",CLP_RepContact$MailingCountry)
CLP_RepContact$MailingCountry<-gsub("54", "Argentina",CLP_RepContact$MailingCountry)
CLP_RepContact$MailingCountry<-gsub("34", "Espa�a",CLP_RepContact$MailingCountry)
CLP_RepContact$MailingCountry<-gsub("12", "Estados Unidos",CLP_RepContact$MailingCountry)
CLP_RepContact$MailingCountry<-gsub("33", "Francia",CLP_RepContact$MailingCountry)
CLP_RepContact$MailingCountry<-gsub("59", "Bolivia",CLP_RepContact$MailingCountry)

Company<- sqldf('SELECT DISTINCT CLP_RepContact.Company as Company FROM CLP_RepContact')

# Hago fuzzy join entre los nombres de cuentas del representante 
# install.packages("fuzzyjoin")

Company$NameMod <- tolower(Company$Company)

lj<-NULL
lj<-Company %>%
  stringdist_left_join(CLP_Account[c("NameMod","ACRNM__c","Id")], by = c(NameMod = "NameMod"), max_dist=2)
# hay 11 que joinean contra lo que esta en ya armados de cuentas. Los filtros y appendeo los que mo.
lj1 <- filter(lj, is.na(NameMod.y))
lj1$NameMod.x <- NULL
lj1$NameMod.y <- NULL

colnames(CLP_Account1)
CLP_Account1<- CLP_Account[-c(2,4,5,20,21,22)]

                      
lj1$Name <- lj1$Company
lj1$Company<-NULL
lj1$Abbreviation__c <- NA              
lj1$OwnerId <- NA                      
lj1$BillingStreet <- NA
lj1$BillingCity <- NA
lj1$BillingPostalCode <- NA
lj1$Website <- NA                      
lj1$Description  <- NA                 
lj1$Institution_Type__c <- NA           
lj1$Institution_Sub_type__c  <- NA    
lj1$Public_Private_Sector__c <- NA      
lj1$Relationship_with_the_bank__c <- NA
lj1$ParentId <- NA                      
lj1$email__c <- NA                     
lj1$Phone <- NA                        
lj1$PersonMobilePhone <- NA
lj1$BillingCountry <- NA
lj1$BillingCountryCode <- NA     
CLP_Account2<-rbind(CLP_Account1,lj1)

CLP_RepContact1 <- sqldf('SELECT CLP_RepContact.*, lj.ACRNM__c, lj.Id FROM CLP_RepContact LEFT JOIN lj ON CLP_RepContact.Company=lj.Company')
CLP_RepContact1$AccountId <- CLP_RepContact1$Id
CLP_RepContact1$Id <- NULL
CLP_RepContact1$ACRNM__c <- NULL
CLP_RepContact1$Company <- NULL

setdiff(colnames(CLP_RepContact1), colnames(CLP_RepContact))
Path = "/Users/rfpardo/documents/Rdata/"
AccountPath = paste0(Path,"RP_CLP_RepContact_",format(Sys.time(), "%d-%b-%Y %H.%M"), ".Rda")
save(CLP_RepContact1,file=AccountPath)

Path = "C:/Users/rfpardo/Documents/RP_CLP201906/"
TablePath = paste0(Path,"RP_CLP_Account_",format(Sys.time(), "%d-%b-%Y %H.%M"), ".csv")
TablePath1 = paste0(Path,"RP_CLP_Contact_",format(Sys.time(), "%d-%b-%Y %H.%M"), ".csv")

colnames(CLP_Account)

colnames(CLP_RepContact1)
CLP_RepContact2<- CLP_RepContact1[-c(2,4,5,20,21,22)]

write.table(CLP_Account2,TablePath,row.names=FALSE, na="", sep=",")
write.table(CLP_RepContact1,TablePath1,row.names=FALSE, na="", sep=",")

